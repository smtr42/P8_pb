$(".product-input").autocomplete({
    source: autocomplete_url,
    minLength: 3

});

$("#product-input-header").autocomplete({
    source: autocomplete_url,
    minLength: 3
});
